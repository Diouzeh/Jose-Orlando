package com.app.entidade;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Usuario {
	
	@Id
	@GeneratedValue
	private Long id;
	private String pnome;
	private String unome;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPnome() {
		return pnome;
	}
	public void setPnome(String pnome) {
		this.pnome = pnome;
	}
	public String getUnome() {
		return unome;
	}
	public void setUnome(String unome) {
		this.unome = unome;
	}
	public Usuario(String pnome, String unome) {
		this.pnome = pnome;
		this.unome = unome;
	}
	public Usuario() {
		
	}
	@Override
	public String toString() {
		return "Usuario [id=" + id + ", pnome=" + pnome + ", unome=" + unome + "]";
	}
	
	
	
	
}
