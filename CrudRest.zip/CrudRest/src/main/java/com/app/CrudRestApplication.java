package com.app;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import com.app.entidade.Usuario;
import com.app.repositorio.RepositorioUsuario;

@SpringBootApplication
public class CrudRestApplication implements CommandLineRunner {

	@Autowired
	private RepositorioUsuario repositorioUsuario;
	
	
	public static void main(String[] args) {
		SpringApplication.run(CrudRestApplication.class, args);
	}

	@Override
	public void run(String... arg0) throws Exception {
		repositorioUsuario.save(new Usuario("one","one"));
		repositorioUsuario.save(new Usuario("two","one"));
		repositorioUsuario.save(new Usuario("three","one"));
		repositorioUsuario.save(new Usuario("Monica","one"));
		
	}
}
