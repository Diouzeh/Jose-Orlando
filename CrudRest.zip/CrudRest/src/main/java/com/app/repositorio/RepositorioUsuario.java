package com.app.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.app.entidade.Usuario;

public interface RepositorioUsuario extends JpaRepository<Usuario,Long>{

}
